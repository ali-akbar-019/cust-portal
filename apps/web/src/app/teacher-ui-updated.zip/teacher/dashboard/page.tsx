'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useAuth } from '@/lib/auth-context';
import { apiFetch } from '@/lib/api-client';
import { PageHeader } from '@/components/ui/page-header';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface MySection {
  id: string;
  course: { title: string; code: string };
  enrolledCount: number;
  capacity: number;
}

const LINKS = [
  { href: '/teacher/timetable', label: 'My Timetable', desc: 'View your weekly teaching schedule' },
  { href: '/teacher/attendance', label: 'Mark Attendance', desc: 'Take attendance for a section' },
  { href: '/teacher/assignments', label: 'Assignments', desc: 'Post work and grade submissions' },
  { href: '/teacher/grades', label: 'Enter Grades', desc: 'Manage component-wise marks' },
  { href: '/teacher/feedback', label: 'Section Feedback', desc: 'Review anonymized student feedback' },
];

export default function TeacherDashboardPage() {
  const { accessToken, profile } = useAuth();
  const [sections, setSections] = useState<MySection[]>([]);

  useEffect(() => {
    if (!accessToken || !profile?.teacherId) return;
    apiFetch<MySection[]>(`/teachers/${profile.teacherId}/sections`, { token: accessToken })
      .then(setSections)
      .catch(() => setSections([]));
  }, [accessToken, profile?.teacherId]);

  const totalStudents = sections.reduce((sum, section) => sum + section.enrolledCount, 0);
  const averageSize = sections.length ? Math.round(totalStudents / sections.length) : 0;
  const chartData = sections.map((section) => ({
    code: section.course.code,
    enrolled: section.enrolledCount,
    capacity: section.capacity,
  }));

  return (
    <main className="min-w-0 max-w-full overflow-x-hidden p-4 sm:p-6 lg:p-10">
      <PageHeader
        eyebrow="Faculty"
        title="Dashboard"
        subtitle={profile?.email ?? 'Your teaching overview'}
      />

      <section className="mb-8 grid grid-cols-1 gap-3 sm:grid-cols-3">
        {[
          ['Sections Teaching', sections.length.toString()],
          ['Total Students', totalStudents.toString()],
          ['Average Section Size', sections.length ? averageSize.toString() : '—'],
        ].map(([label, value]) => (
          <div key={label} className="rounded-xl border border-slate-200 bg-white/90 p-5 shadow-sm backdrop-blur-sm">
            <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-400">{label}</p>
            <p className="mt-2 font-serif text-3xl font-semibold tracking-tight text-slate-900">{value}</p>
          </div>
        ))}
      </section>

      {sections.length > 0 && (
        <section className="mb-8 rounded-2xl border border-slate-200 bg-white/90 p-4 shadow-sm backdrop-blur-sm sm:p-6">
          <div className="mb-5">
            <h2 className="font-serif text-lg font-semibold text-slate-900">Enrollment overview</h2>
            <p className="mt-1 text-sm text-slate-500">Current students compared with each section's capacity.</p>
          </div>
          <div className="h-[240px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 8, right: 8, left: -22, bottom: 0 }}>
                <CartesianGrid vertical={false} stroke="var(--color-slate-100)" />
                <XAxis dataKey="code" tick={{ fontSize: 11, fill: 'var(--color-slate-400)' }} axisLine={false} tickLine={false} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: 'var(--color-slate-400)' }} axisLine={false} tickLine={false} width={30} />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 10, border: '1px solid var(--color-slate-200)', boxShadow: '0 8px 24px rgba(15,23,42,.08)' }} />
                <Bar dataKey="capacity" fill="var(--color-slate-200)" radius={[5, 5, 0, 0]} name="Capacity" />
                <Bar dataKey="enrolled" fill="var(--color-slate-900)" radius={[5, 5, 0, 0]} name="Enrolled" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </section>
      )}

      <section>
        <div className="mb-4">
          <h2 className="font-serif text-lg font-semibold text-slate-900">Quick actions</h2>
          <p className="mt-1 text-sm text-slate-500">Jump directly to the tools you use most.</p>
        </div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="group rounded-xl border border-slate-200 bg-white/90 p-5 shadow-sm transition duration-200 hover:-translate-y-0.5 hover:border-slate-300 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-slate-900/10"
            >
              <div className="flex items-start justify-between gap-4">
                <div>
                  <h3 className="font-medium text-slate-900">{link.label}</h3>
                  <p className="mt-1 text-sm leading-6 text-slate-500">{link.desc}</p>
                </div>
                <span className="text-slate-300 transition group-hover:translate-x-0.5 group-hover:text-slate-600">→</span>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </main>
  );
}
