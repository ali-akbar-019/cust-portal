'use client';

import { useEffect, useState } from 'react';
import { useAuth } from '@/lib/auth-context';
import { apiFetch, ApiError } from '@/lib/api-client';
import { PageHeader } from '@/components/ui/page-header';

interface MySection {
  id: string;
  course: { title: string; code: string };
  enrolledCount: number;
}
interface RosterStudent {
  id: string;
  enrollmentNo: string;
  user: { email: string };
  attendances: { status: 'PRESENT' | 'ABSENT' }[];
}

export default function TeacherAttendancePage() {
  const { accessToken, profile } = useAuth();
  const [mySections, setMySections] = useState<MySection[]>([]);
  const [sectionId, setSectionId] = useState('');
  const [date, setDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [roster, setRoster] = useState<RosterStudent[]>([]);
  const [statuses, setStatuses] = useState<Record<string, 'PRESENT' | 'ABSENT'>>({});
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loadingRoster, setLoadingRoster] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!accessToken || !profile?.teacherId) return;
    apiFetch<MySection[]>(`/teachers/${profile.teacherId}/sections`, { token: accessToken })
      .then((sections) => {
        setMySections(sections);
        setSectionId(sections[0]?.id ?? '');
      })
      .catch((err) => setError(err instanceof ApiError ? err.message : 'Failed to load sections'));
  }, [accessToken, profile?.teacherId]);

  async function loadRoster() {
    if (!sectionId || !date || !accessToken) return;
    setLoadingRoster(true);
    setError(null);
    setMessage(null);
    try {
      const data = await apiFetch<RosterStudent[]>(`/attendance/section/${sectionId}/roster?date=${date}`, { token: accessToken });
      setRoster(data);
      const initial: Record<string, 'PRESENT' | 'ABSENT'> = {};
      data.forEach((student) => { initial[student.id] = student.attendances[0]?.status ?? 'PRESENT'; });
      setStatuses(initial);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to load roster');
      setRoster([]);
    } finally {
      setLoadingRoster(false);
    }
  }

  useEffect(() => { void loadRoster(); }, [sectionId, date]);

  function markAll(status: 'PRESENT' | 'ABSENT') {
    const next: Record<string, 'PRESENT' | 'ABSENT'> = {};
    roster.forEach((student) => { next[student.id] = status; });
    setStatuses(next);
  }

  async function handleSubmit() {
    if (!accessToken || !sectionId || !roster.length) return;
    setSaving(true);
    setMessage(null);
    setError(null);
    try {
      const records = Object.entries(statuses).map(([studentId, status]) => ({ studentId, status }));
      const res = await apiFetch<{ markedCount: number }>('/attendance/mark', {
        method: 'POST',
        token: accessToken,
        body: JSON.stringify({ sectionId, date, records }),
      });
      setMessage(`Attendance recorded for ${res.markedCount} students.`);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to submit attendance');
    } finally {
      setSaving(false);
    }
  }

  const presentCount = Object.values(statuses).filter((status) => status === 'PRESENT').length;
  const absentCount = Math.max(0, roster.length - presentCount);
  const currentCourse = mySections.find((section) => section.id === sectionId);

  return (
    <main className="min-w-0 max-w-full overflow-x-hidden p-4 sm:p-6 lg:p-10">
      <PageHeader eyebrow="Faculty" title="Mark Attendance" subtitle="Take the register for a section and date. Re-marking updates the existing sheet." />

      <section className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
        <div className="col-span-2 rounded-xl border border-slate-200 bg-white/90 p-4 shadow-sm sm:col-span-1">
          <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-400">Course</p>
          <p className="mt-2 truncate font-data text-sm font-semibold text-slate-900">{currentCourse?.course.code ?? '—'}</p>
          <p className="mt-1 truncate text-xs text-slate-500">{currentCourse?.course.title ?? 'No section selected'}</p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white/90 p-4 shadow-sm">
          <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-400">Present</p>
          <p className="mt-2 font-serif text-2xl font-semibold text-slate-900">{presentCount}</p>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white/90 p-4 shadow-sm">
          <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-400">Absent</p>
          <p className="mt-2 font-serif text-2xl font-semibold text-slate-900">{absentCount}</p>
        </div>
      </section>

      <section className="mb-6 rounded-xl border border-slate-200 bg-white/90 p-4 shadow-sm sm:p-5">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-[minmax(0,1fr)_auto]">
          <label className="min-w-0">
            <span className="mb-1.5 block text-xs font-semibold uppercase tracking-[0.12em] text-slate-500">Section</span>
            <select value={sectionId} onChange={(e) => setSectionId(e.target.value)} className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-800 outline-none focus:border-slate-900 focus:ring-2 focus:ring-slate-900/10">
              {mySections.length === 0 && <option value="">No sections assigned</option>}
              {mySections.map((section) => <option key={section.id} value={section.id}>{section.course.title} ({section.course.code}) · {section.enrolledCount} students</option>)}
            </select>
          </label>
          <label className="md:w-48">
            <span className="mb-1.5 block text-xs font-semibold uppercase tracking-[0.12em] text-slate-500">Date</span>
            <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-800 outline-none focus:border-slate-900 focus:ring-2 focus:ring-slate-900/10" />
          </label>
        </div>
      </section>

      {error && <div className="mb-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>}
      {message && <div className="mb-4 rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700">{message}</div>}

      {loadingRoster ? (
        <div className="rounded-xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-500">Loading roster…</div>
      ) : roster.length === 0 ? (
        sectionId && <div className="rounded-xl border border-dashed border-slate-300 bg-white/70 p-8 text-center text-sm text-slate-500">No students enrolled in this section yet.</div>
      ) : (
        <section className="overflow-hidden rounded-xl border border-slate-200 bg-white/90 shadow-sm">
          <div className="flex flex-col gap-3 border-b border-slate-200 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h2 className="font-serif text-lg font-semibold text-slate-900">Class register</h2>
              <p className="text-xs text-slate-500">{roster.length} students · {date}</p>
            </div>
            <div className="flex flex-wrap gap-2">
              <button onClick={() => markAll('PRESENT')} className="rounded-lg border border-slate-300 px-3 py-2 text-xs font-medium text-slate-700 transition hover:bg-slate-50">Mark all present</button>
              <button onClick={() => markAll('ABSENT')} className="rounded-lg border border-slate-300 px-3 py-2 text-xs font-medium text-slate-700 transition hover:bg-slate-50">Mark all absent</button>
            </div>
          </div>

          <div className="divide-y divide-slate-100">
            {roster.map((student) => (
              <div key={student.id} className="flex flex-col gap-3 px-4 py-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="min-w-0">
                  <p className="font-data text-sm font-semibold text-slate-800">{student.enrollmentNo}</p>
                  <p className="mt-0.5 truncate text-xs text-slate-400">{student.user.email}</p>
                </div>
                <div className="grid grid-cols-2 gap-1.5 sm:w-44">
                  {(['PRESENT', 'ABSENT'] as const).map((option) => {
                    const selected = statuses[student.id] === option;
                    return (
                      <button
                        key={option}
                        onClick={() => setStatuses((prev) => ({ ...prev, [student.id]: option }))}
                        className={`rounded-lg px-3 py-2 text-xs font-medium transition ${selected ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}
                      >
                        {option === 'PRESENT' ? 'Present' : 'Absent'}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          <div className="border-t border-slate-200 bg-slate-50/70 p-4">
            <button onClick={handleSubmit} disabled={saving} className="w-full rounded-lg bg-slate-900 px-5 py-2.5 text-sm font-medium text-white transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-50 sm:w-auto">
              {saving ? 'Saving…' : 'Submit Attendance'}
            </button>
          </div>
        </section>
      )}
    </main>
  );
}
