'use client';

import { useEffect, useMemo, useState } from 'react';
import { useAuth } from '@/lib/auth-context';
import { apiFetch, ApiError } from '@/lib/api-client';
import { PageHeader } from '@/components/ui/page-header';

interface SlotView {
  id: string;
  day: string;
  startTime: string;
  endTime: string;
  room: { label: string; floor: { block: { name: string } } };
  section: { course: { title: string; code: string } };
}

const DAY_ORDER = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
const DAY_LABEL: Record<string, string> = { MON: 'Mon', TUE: 'Tue', WED: 'Wed', THU: 'Thu', FRI: 'Fri', SAT: 'Sat' };

export default function TeacherTimetablePage() {
  const { accessToken, profile, isLoading: authLoading } = useAuth();
  const [slots, setSlots] = useState<SlotView[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (authLoading || !accessToken) return;
    if (!profile?.teacherId) {
      setError('Could not resolve your teacher profile. Try logging out and back in.');
      setIsLoading(false);
      return;
    }
    apiFetch<SlotView[]>(`/teachers/${profile.teacherId}/timetable`, { token: accessToken })
      .then(setSlots)
      .catch((err) => setError(err instanceof ApiError ? err.message : 'Failed to load timetable'))
      .finally(() => setIsLoading(false));
  }, [accessToken, profile?.teacherId, authLoading]);

  const uniqueTimes = useMemo(() => [...new Set(slots.map((slot) => slot.startTime))].sort(), [slots]);
  const slotAt = (day: string, time: string) => slots.find((slot) => slot.day === day && slot.startTime === time);

  if (isLoading) return <main className="p-4 sm:p-6 lg:p-10"><PageHeader eyebrow="Weekly Schedule" title="My Teaching Schedule" subtitle="Your assigned classes across the week." /><div className="rounded-xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-500">Loading timetable…</div></main>;
  if (error) return <main className="p-4 sm:p-6 lg:p-10"><PageHeader eyebrow="Weekly Schedule" title="My Teaching Schedule" subtitle="Your assigned classes across the week." /><div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div></main>;

  return (
    <main className="min-w-0 max-w-full overflow-x-hidden p-4 sm:p-6 lg:p-10">
      <PageHeader eyebrow="Weekly Schedule" title="My Teaching Schedule" subtitle="A compact view of your teaching slots by day and time." />

      {slots.length === 0 ? (
        <div className="rounded-xl border border-dashed border-slate-300 bg-white/70 p-10 text-center text-sm text-slate-500">No timetable slots have been assigned yet.</div>
      ) : (
        <>
          <div className="mb-5 rounded-xl border border-slate-200 bg-white/90 p-3 shadow-sm sm:p-4">
            <div className="mb-3 flex items-center justify-between">
              <div>
                <h2 className="font-serif text-base font-semibold text-slate-900">Weekly grid</h2>
                <p className="text-xs text-slate-500">{slots.length} teaching slot{slots.length === 1 ? '' : 's'}</p>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[760px] border-collapse text-sm">
                <thead>
                  <tr>
                    <th className="w-20 border-b border-slate-200 p-3 text-left text-[10px] font-semibold uppercase tracking-[0.14em] text-slate-400">Time</th>
                    {DAY_ORDER.map((day) => <th key={day} className="border-b border-slate-200 p-3 text-left text-[10px] font-semibold uppercase tracking-[0.14em] text-slate-400">{DAY_LABEL[day]}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {uniqueTimes.map((time) => (
                    <tr key={time}>
                      <td className="border-b border-slate-100 p-3 align-top font-data text-xs text-slate-400">{time}</td>
                      {DAY_ORDER.map((day) => {
                        const slot = slotAt(day, time);
                        return (
                          <td key={day} className="border-b border-slate-100 p-2 align-top">
                            {slot ? (
                              <div className="min-h-[84px] rounded-lg border border-slate-200 bg-slate-50 p-3">
                                <p className="font-data text-xs font-semibold text-slate-900">{slot.section.course.code}</p>
                                <p className="mt-1 line-clamp-2 text-xs leading-5 text-slate-600">{slot.section.course.title}</p>
                                <p className="mt-2 text-[10px] text-slate-400">{slot.room.floor.block.name} · {slot.room.label}</p>
                                <p className="mt-0.5 font-data text-[10px] text-slate-400">{slot.startTime}–{slot.endTime}</p>
                              </div>
                            ) : <div className="min-h-[84px] rounded-lg border border-dashed border-slate-100" />}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {slots.map((slot) => (
              <div key={slot.id} className="rounded-xl border border-slate-200 bg-white/90 p-4 shadow-sm">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-data text-xs font-semibold text-slate-900">{slot.section.course.code}</p>
                    <p className="mt-1 truncate text-sm text-slate-600">{slot.section.course.title}</p>
                  </div>
                  <span className="shrink-0 rounded-md bg-slate-100 px-2 py-1 text-[10px] font-medium text-slate-500">{DAY_LABEL[slot.day] ?? slot.day}</span>
                </div>
                <p className="mt-3 text-xs text-slate-500">{slot.startTime}–{slot.endTime} · {slot.room.floor.block.name}-{slot.room.label}</p>
              </div>
            ))}
          </div>
        </>
      )}
    </main>
  );
}
