'use client';

import { useEffect, useState } from 'react';
import { useAuth } from '@/lib/auth-context';
import { apiFetch, ApiError } from '@/lib/api-client';
import { PageHeader, EmptyState } from '@/components/ui/page-header';

interface MySection {
  id: string;
  course: { title: string; code: string };
  enrolledCount: number;
}
interface FeedbackSummary {
  count: number;
  average: number | null;
  comments: (string | null)[];
}

export default function TeacherFeedbackPage() {
  const { accessToken, profile } = useAuth();
  const [sections, setSections] = useState<MySection[]>([]);
  const [sectionId, setSectionId] = useState('');
  const [summary, setSummary] = useState<FeedbackSummary | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!accessToken || !profile?.teacherId) return;
    apiFetch<MySection[]>(`/teachers/${profile.teacherId}/sections`, { token: accessToken })
      .then((data) => { setSections(data); setSectionId(data[0]?.id ?? ''); })
      .catch((err) => setError(err instanceof ApiError ? err.message : 'Failed to load sections'));
  }, [accessToken, profile?.teacherId]);

  useEffect(() => {
    if (!sectionId || !accessToken) { setSummary(null); return; }
    setIsLoading(true);
    setError(null);
    apiFetch<FeedbackSummary>(`/feedback/section/${sectionId}`, { token: accessToken })
      .then(setSummary)
      .catch((err) => setError(err instanceof ApiError ? err.message : 'Failed to load feedback'))
      .finally(() => setIsLoading(false));
  }, [sectionId, accessToken]);

  const current = sections.find((section) => section.id === sectionId);

  return (
    <main className="min-w-0 max-w-full overflow-x-hidden p-4 sm:p-6 lg:p-10">
      <PageHeader eyebrow="Course Evaluation" title="Section Feedback" subtitle="Review anonymized ratings and written comments from your students." />

      <section className="mb-6 rounded-xl border border-slate-200 bg-white/90 p-4 shadow-sm sm:p-5">
        <label className="block max-w-2xl">
          <span className="mb-1.5 block text-xs font-semibold uppercase tracking-[0.12em] text-slate-500">Section</span>
          <select value={sectionId} onChange={(e) => setSectionId(e.target.value)} className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-800 outline-none focus:border-slate-900 focus:ring-2 focus:ring-slate-900/10">
            {sections.length === 0 && <option value="">No sections assigned</option>}
            {sections.map((section) => <option key={section.id} value={section.id}>{section.course.title} ({section.course.code}) · {section.enrolledCount} students</option>)}
          </select>
        </label>
      </section>

      {error && <div className="mb-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>}
      {isLoading && <div className="rounded-xl border border-slate-200 bg-white p-8 text-center text-sm text-slate-500">Loading feedback…</div>}

      {summary && !isLoading && (
        <>
          <section className="mb-8 grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div className="rounded-xl border border-slate-200 bg-white/90 p-5 shadow-sm sm:col-span-1">
              <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-400">Course</p>
              <p className="mt-2 font-medium leading-6 text-slate-900">{current ? `${current.course.title} (${current.course.code})` : '—'}</p>
            </div>
            <div className="rounded-xl border border-slate-200 bg-white/90 p-5 shadow-sm">
              <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-400">Average rating</p>
              <p className="mt-2 font-serif text-3xl font-semibold text-slate-900">{summary.average ?? '—'}<span className="ml-1 text-sm font-normal text-slate-400">/ 5</span></p>
            </div>
            <div className="rounded-xl border border-slate-200 bg-white/90 p-5 shadow-sm">
              <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-400">Responses</p>
              <p className="mt-2 font-serif text-3xl font-semibold text-slate-900">{summary.count}</p>
            </div>
          </section>

          {summary.average !== null && (
            <section className="mb-8 max-w-xl rounded-xl border border-slate-200 bg-white/90 p-5 shadow-sm">
              <div className="flex items-end justify-between gap-4">
                <div>
                  <h2 className="font-serif text-base font-semibold text-slate-900">Satisfaction</h2>
                  <p className="mt-1 text-sm text-slate-500">Average student rating</p>
                </div>
                <span className="font-data text-sm font-semibold text-slate-800">{summary.average.toFixed(1)} / 5</span>
              </div>
              <div className="mt-4 h-2 overflow-hidden rounded-full bg-slate-100">
                <div className="h-full rounded-full bg-slate-900 transition-all" style={{ width: `${Math.min(100, (summary.average / 5) * 100)}%` }} />
              </div>
              <p className="mt-3 text-xs leading-5 text-slate-500">
                {summary.average >= 4 ? 'Strong overall satisfaction.' : summary.average >= 3 ? 'Generally positive, with room to improve.' : 'Consider reviewing the areas students are finding difficult.'}
              </p>
            </section>
          )}

          {summary.comments.length === 0 && summary.count > 0 ? (
            <EmptyState title="Responses received, no comments" hint="Students rated the course but left no written feedback." />
          ) : summary.count === 0 ? (
            <EmptyState title="No feedback yet" hint="Student evaluations will appear here when responses are submitted." />
          ) : (
            <section className="max-w-3xl">
              <div className="mb-4">
                <h2 className="font-serif text-lg font-semibold text-slate-900">Student comments</h2>
                <p className="mt-1 text-sm text-slate-500">Comments are shown anonymously.</p>
              </div>
              <div className="grid gap-3">
                {summary.comments.filter((comment): comment is string => Boolean(comment?.trim())).map((comment, index) => (
                  <blockquote key={index} className="rounded-xl border border-slate-200 bg-white/90 p-5 text-sm leading-6 text-slate-600 shadow-sm">
                    <span className="mr-2 text-slate-300">“</span>{comment}<span className="ml-1 text-slate-300">”</span>
                  </blockquote>
                ))}
              </div>
            </section>
          )}
        </>
      )}
    </main>
  );
}
