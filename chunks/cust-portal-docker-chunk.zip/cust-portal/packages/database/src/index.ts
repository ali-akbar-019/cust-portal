import { PrismaClient } from '@prisma/client';

// Reuse a single PrismaClient instance across the app (avoids exhausting
// DB connections in dev with hot-reload).
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

export const prisma = globalForPrisma.prisma ?? new PrismaClient();

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = prisma;
}

export * from '@prisma/client';
