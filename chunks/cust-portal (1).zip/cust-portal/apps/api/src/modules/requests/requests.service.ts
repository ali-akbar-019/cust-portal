import { Injectable } from '@nestjs/common';

@Injectable()
export class RequestsService {
  // TODO: implement business logic
}
